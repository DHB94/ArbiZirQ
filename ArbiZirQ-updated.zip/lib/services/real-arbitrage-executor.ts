// Real Arbitrage Execution Service using Wagmi/Viem
import { 
  writeContract, 
  readContract, 
  getAccount, 
  getPublicClient,
  getWalletClient,
  switchChain,
  waitForTransactionReceipt
} from '@wagmi/core'
import { parseUnits, formatUnits, encodeFunctionData } from 'viem'
import type { ExecuteRequest, ExecutionResult, Opportunity } from '@/lib/types'
import { config } from '@/lib/web3-config'

// DEX Router Contract ABIs (simplified)
const UNISWAP_V2_ROUTER_ABI = [
  {
    name: 'swapExactTokensForTokens',
    type: 'function',
    inputs: [
      { name: 'amountIn', type: 'uint256' },
      { name: 'amountOutMin', type: 'uint256' },
      { name: 'path', type: 'address[]' },
      { name: 'to', type: 'address' },
      { name: 'deadline', type: 'uint256' }
    ],
    outputs: [{ name: 'amounts', type: 'uint256[]' }]
  }
] as const

const ERC20_ABI = [
  {
    name: 'approve',
    type: 'function',
    inputs: [
      { name: 'spender', type: 'address' },
      { name: 'amount', type: 'uint256' }
    ],
    outputs: [{ name: '', type: 'bool' }]
  },
  {
    name: 'balanceOf',
    type: 'function',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }]
  },
  {
    name: 'transfer',
    type: 'function',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' }
    ],
    outputs: [{ name: '', type: 'bool' }]
  }
] as const

// Contract addresses by chain
const ROUTER_ADDRESSES = {
  1: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D', // Ethereum Uniswap V2
  137: '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff', // Polygon QuickSwap
  42161: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506', // Arbitrum SushiSwap
  8453: '0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24', // Base BaseSwap
  48900: '0x0000000000000000000000000000000000000000', // Zircuit (placeholder)
} as const

const TOKEN_ADDRESSES = {
  // USDC addresses by chain
  USDC: {
    1: '0xA0b86a33E6441E7C0000A064f8008D4C86f1Af32', // Ethereum
    137: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', // Polygon
    42161: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8', // Arbitrum
    8453: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // Base
    48900: '0x0000000000000000000000000000000000000000', // Zircuit
  },
  // USDT addresses by chain
  USDT: {
    1: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // Ethereum
    137: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F', // Polygon
    42161: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9', // Arbitrum
    8453: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2', // Base
    48900: '0x0000000000000000000000000000000000000000', // Zircuit
  }
} as const

/**
 * Execute real arbitrage opportunity using DEX swaps
 */

export async function executeRealArbitrage(request: ExecuteRequest): Promise<ExecutionResult> {
  console.log('🚀 Starting REAL arbitrage execution for:', request.id)
  const startTime = Date.now()
  const receipts: any[] = []
  try {
    // Serverless-safe account detection:
    // Prefer connected wallet (client-side). If not present, fall back to server-side PRIVATE_KEY (required for server execution).
    let account: { address?: `0x${string}` } = {};
    try {
      account = getAccount(config) || {};
    } catch (e) {
      console.log('getAccount() not available in this runtime:', e?.message ?? e)
      account = {}
    }
    
    if (!account.address) {
      // try server-side private key
      if (process.env.PRIVATE_KEY && process.env.RPC_URL) {
        console.log('Using server-side PRIVATE_KEY and RPC_URL for signing (server execution)')
        try {
          // lazy import ethers to avoid increasing cold-start for client bundles
          // @ts-ignore
          const { Wallet, providers } = await import('ethers');
          const provider = new providers.JsonRpcProvider(process.env.RPC_URL)
          const wallet = new Wallet(process.env.PRIVATE_KEY, provider)
          account.address = wallet.address
          // Attach a simple signer helper to config if needed by downstream functions
          // Note: many wagmi writeContract/readContract helpers expect a walletClient; if those fail, fall back to raw ethers signer in future updates.
          ;(config as any).__serverSigner = wallet
        } catch (err) {
          console.error('Failed to create server-side wallet signer:', err)
          return { success: false, error: 'Failed to create server-side signer: ' + String(err) }
        }
      } else {
        console.error('No connected wallet and no server PRIVATE_KEY/RPC_URL configured.')
        return { success: false, error: 'No wallet available: connect Metamask or set PRIVATE_KEY and RPC_URL in environment' }
      }
    }

    // Step 1: Execute buy leg on source chain
    console.log('💰 Executing buy leg on', request.sourceChain)
    await switchChain(config, { chainId: getChainId(request.sourceChain) as any })

    const buyTxHash = await executeBuyLeg(request, account.address)
    const buyReceipt = await waitForTransactionReceipt(config, { hash: buyTxHash })
    receipts.push(buyReceipt)

    console.log('✅ Buy leg completed:', buyTxHash)

    // Step 2: Bridge tokens if needed (cross-chain arbitrage)
    if (request.sourceChain !== request.targetChain) {
      console.log('🌉 Bridging tokens from', request.sourceChain, 'to', request.targetChain)
      const bridgeTxHash = await bridgeTokens(request, account.address)
      const bridgeReceipt = await waitForTransactionReceipt(config, { hash: bridgeTxHash })
      receipts.push(bridgeReceipt)

      console.log('✅ Bridge completed:', bridgeTxHash)

      // Wait for bridge settlement
      await waitForBridgeSettlement(bridgeTxHash, request.targetChain)
    }

    // Step 3: Execute sell leg on target chain
    console.log('💸 Executing sell leg on', request.targetChain)
    await switchChain(config, { chainId: getChainId(request.targetChain) as any })

    const sellTxHash = await executeSellLeg(request, account.address)
    const sellReceipt = await waitForTransactionReceipt(config, { hash: sellTxHash })
    receipts.push(sellReceipt)

    console.log('✅ Sell leg completed:', sellTxHash)

    const endTime = Date.now()
    return {
      success: true,
      durationMs: endTime - startTime,
      receipts,
    }
  } catch (error) {
    console.error('❌ Arbitrage execution failed (caught):', error)
    // Return structured error instead of throwing to avoid 500s in serverless
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}


/**
 * Execute buy leg of arbitrage (buy tokens on source chain)
 */

async function executeBuyLeg(request: ExecuteRequest, userAddress: `0x${string}`): Promise<`0x${string}`> {
  const routerAddress = ROUTER_ADDRESSES[getChainId(request.sourceChain) as keyof typeof ROUTER_ADDRESSES]
  const tokenIn = getTokenAddress(request.pair.quote, request.sourceChain) // USDT/USDC
  const tokenOut = getTokenAddress(request.pair.base, request.sourceChain) // The token we're buying
  
  const amountIn = parseUnits(request.sizeDollar.toString(), 6) // Assuming 6 decimals for stablecoins
  const amountOutMin = calculateMinAmountOut(request.buyQuote.price, request.sizeDollar, request.maxSlippageBps)
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 1200) // 20 minutes

  // If simulation forced, return mock tx hash
  if (process.env.FORCE_SIMULATION === 'true') {
    return '0x' + 'f'.repeat(64)
  }

  // Server-side signer fallback
  const serverSigner = (config as any).__serverSigner
  if (serverSigner) {
    try {
      const { ethers } = await import('ethers')
      // Approve token spending via server signer
      const tokenContract = new (ethers as any).Contract(tokenIn, ERC20_ABI as any, serverSigner)
      const approveTx = await tokenContract.approve(routerAddress, amountIn.toString())
      console.log('approve tx sent (server):', approveTx.hash)
      // don't wait for confirmation, return after broadcast
      // Execute swap via router
      const router = new (ethers as any).Contract(routerAddress, UNISWAP_V2_ROUTER_ABI as any, serverSigner)
      const swapTx = await router.swapExactTokensForTokens(
        amountIn.toString(),
        amountOutMin.toString(),
        [tokenIn, tokenOut],
        userAddress,
        Number(deadline)
      )
      console.log('swap tx sent (server):', swapTx.hash)
      return swapTx.hash as `0x${string}`
    } catch (err) {
      console.error('Server-side buy leg failed:', err)
      throw err
    }
  }

  // Fallback to client-side writeContract (original behavior)
  await writeContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'approve',
    args: [routerAddress, amountIn],
  })

  const txHash = await writeContract(config, {
    address: routerAddress,
    abi: UNISWAP_V2_ROUTER_ABI,
    functionName: 'swapExactTokensForTokens',
    args: [
      amountIn,
      amountOutMin,
      [tokenIn, tokenOut],
      userAddress,
      deadline
    ],
  })

  return txHash
}
`): Promise<`0x${string}`> {
  const routerAddress = ROUTER_ADDRESSES[getChainId(request.sourceChain) as keyof typeof ROUTER_ADDRESSES]
  const tokenIn = getTokenAddress(request.pair.quote, request.sourceChain) // USDT/USDC
  const tokenOut = getTokenAddress(request.pair.base, request.sourceChain) // The token we're buying
  
  const amountIn = parseUnits(request.sizeDollar.toString(), 6) // Assuming 6 decimals for stablecoins
  const amountOutMin = calculateMinAmountOut(request.buyQuote.price, request.sizeDollar, request.maxSlippageBps)
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 1200) // 20 minutes

  // Approve token spending
  await writeContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'approve',
    args: [routerAddress, amountIn],
  })

  // Execute swap
  const txHash = await writeContract(config, {
    address: routerAddress,
    abi: UNISWAP_V2_ROUTER_ABI,
    functionName: 'swapExactTokensForTokens',
    args: [
      amountIn,
      amountOutMin,
      [tokenIn, tokenOut],
      userAddress,
      deadline
    ],
  })

  return txHash
}

/**
 * Execute sell leg of arbitrage (sell tokens on target chain)
 */

async function executeSellLeg(request: ExecuteRequest, userAddress: `0x${string}`): Promise<`0x${string}`> {
  const routerAddress = ROUTER_ADDRESSES[getChainId(request.targetChain) as keyof typeof ROUTER_ADDRESSES]
  const tokenIn = getTokenAddress(request.pair.base, request.targetChain) // The token we're selling
  const tokenOut = getTokenAddress(request.pair.quote, request.targetChain) // USDT/USDC
  
  // Get current balance of the token we want to sell
  const balance = await readContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: [userAddress],
  })

  const amountIn = balance // Sell all tokens received from buy leg
  const amountOutMin = calculateMinAmountOut(request.sellQuote.price, request.sizeDollar, request.maxSlippageBps)
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 1200) // 20 minutes

  // If simulation forced, return mock tx hash
  if (process.env.FORCE_SIMULATION === 'true') {
    return '0x' + 'f'.repeat(64)
  }

  const serverSigner = (config as any).__serverSigner
  if (serverSigner) {
    try {
      const { ethers } = await import('ethers')
      const tokenContract = new (ethers as any).Contract(tokenIn, ERC20_ABI as any, serverSigner)
      const approveTx = await tokenContract.approve(routerAddress, amountIn.toString())
      console.log('approve tx sent (server sell):', approveTx.hash)
      const router = new (ethers as any).Contract(routerAddress, UNISWAP_V2_ROUTER_ABI as any, serverSigner)
      const swapTx = await router.swapExactTokensForTokens(
        amountIn.toString(),
        amountOutMin.toString(),
        [tokenIn, tokenOut],
        userAddress,
        Number(deadline)
      )
      console.log('swap tx sent (server sell):', swapTx.hash)
      return swapTx.hash as `0x${string}`
    } catch (err) {
      console.error('Server-side sell leg failed:', err)
      throw err
    }
  }

  // Fallback to existing client-side writeContract flow
  await writeContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'approve',
    args: [routerAddress, amountIn],
  })

  const txHash = await writeContract(config, {
    address: routerAddress,
    abi: UNISWAP_V2_ROUTER_ABI,
    functionName: 'swapExactTokensForTokens',
    args: [
      amountIn,
      amountOutMin,
      [tokenIn, tokenOut],
      userAddress,
      deadline
    ],
  })

  return txHash
}
`): Promise<`0x${string}`> {
  const routerAddress = ROUTER_ADDRESSES[getChainId(request.targetChain) as keyof typeof ROUTER_ADDRESSES]
  const tokenIn = getTokenAddress(request.pair.base, request.targetChain) // The token we're selling
  const tokenOut = getTokenAddress(request.pair.quote, request.targetChain) // USDT/USDC
  
  // Get current balance of the token we want to sell
  const balance = await readContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: [userAddress],
  })

  const amountIn = balance // Sell all tokens received from buy leg
  const amountOutMin = calculateMinAmountOut(request.sellQuote.price, request.sizeDollar, request.maxSlippageBps)
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 1200) // 20 minutes

  // Approve token spending
  await writeContract(config, {
    address: tokenIn,
    abi: ERC20_ABI,
    functionName: 'approve',
    args: [routerAddress, amountIn],
  })

  // Execute swap
  const txHash = await writeContract(config, {
    address: routerAddress,
    abi: UNISWAP_V2_ROUTER_ABI,
    functionName: 'swapExactTokensForTokens',
    args: [
      amountIn,
      amountOutMin,
      [tokenIn, tokenOut],
      userAddress,
      deadline
    ],
  })

  return txHash
}

/**
 * Bridge tokens between chains (simplified implementation)
 */
async function bridgeTokens(request: ExecuteRequest, userAddress: `0x${string}`): Promise<`0x${string}`> {
  // This is a placeholder for actual bridge implementation
  // In reality, you would integrate with bridges like:
  // - Stargate (LayerZero)
  // - Across Protocol
  // - Hop Protocol
  // - cBridge (Celer)
  
  console.log('🚧 Bridge integration not implemented yet - using mock transaction')
  
  // For now, return a mock transaction hash
  // In real implementation, this would call the bridge contract
  return ('0x' + Array(64).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('')) as `0x${string}`
}

/**
 * Wait for bridge settlement on target chain
 */
async function waitForBridgeSettlement(txHash: string, targetChain: string): Promise<void> {
  console.log('⏳ Waiting for bridge settlement...')
  
  // In real implementation, this would:
  // 1. Monitor bridge events on source chain
  // 2. Wait for relay confirmation on target chain
  // 3. Verify tokens arrived in user's wallet on target chain
  
  // For now, just wait a fixed time
  await new Promise(resolve => setTimeout(resolve, 30000)) // 30 seconds
  
  console.log('✅ Bridge settlement completed')
}

/**
 * Calculate actual PnL from transaction receipts
 */
async function calculateActualPnL(receipts: any[], request: ExecuteRequest): Promise<number> {
  // In real implementation, this would:
  // 1. Parse swap events from transaction logs
  // 2. Calculate actual tokens received vs sent
  // 3. Convert to USD using current prices
  // 4. Subtract gas costs
  
  // For now, return estimated PnL with some slippage applied
  const slippageImpact = 0.02 // 2% total slippage
  const actualPnl = request.grossPnlUsd * (1 - slippageImpact)
  
  return Math.max(0, actualPnl) // Ensure non-negative
}

/**
 * Helper functions
 */
function getChainId(chain: string): number {
  const chainIds: Record<string, number> = {
    'ethereum': 1,
    'polygon': 137,
    'arbitrum': 42161,
    'base': 8453,
    'zircuit': 48900,
  }
  return chainIds[chain] || 1
}

function getTokenAddress(symbol: string, chain: string): `0x${string}` {
  const chainId = getChainId(chain)
  const addresses = TOKEN_ADDRESSES[symbol as keyof typeof TOKEN_ADDRESSES]
  if (!addresses) {
    throw new Error(`Token ${symbol} not supported`)
  }
  return addresses[chainId as keyof typeof addresses] as `0x${string}`
}

function calculateMinAmountOut(price: number, sizeUsd: number, maxSlippageBps: number): bigint {
  const slippageTolerance = maxSlippageBps / 10000 // Convert bps to decimal
  const expectedAmount = sizeUsd / price
  const minAmount = expectedAmount * (1 - slippageTolerance)
  return parseUnits(minAmount.toFixed(6), 6) // Assuming 6 decimals
}
